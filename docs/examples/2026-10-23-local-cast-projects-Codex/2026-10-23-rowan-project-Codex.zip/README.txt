Open Genjutsu project bundle

This is an execution project, not a model-quality certificate.

1. Install ComfyUI, the workflow's local models and audited custom nodes. See workflow-pack.json provenance and requires. No model weights are redistributed here.
2. Copy the CONTENTS of inputs/ into your ComfyUI input/ directory, preserving its open-genjutsu-22df80c5-cd4d-4000-b4e6-ecbaf762fa29/ subdirectory.
3. portable-workflow-api.json is an API-format graph with ordinary relative input filenames and the original bound parameters. Run it through ComfyUI's prompt API or import workflow-pack.json into Open Genjutsu. API-format JSON is not the frontend canvas/save format.
4. sdk-workflow-receipt.json preserves the actual submitted SDK graph with core/ASSET IDs. Those IDs belong to the original proxy registry; use the portable graph on another machine.
5. manifest.json preserves the original job recipe, engine addresses, input hashes and exact preview normalization. Original source and reference bytes are under originals/. The exact prepared short source and prepared reference used by this execution are under inputs/; legacy receipts may have used the original reference directly. Outputs, if complete, are under outputs/.
6. New preparation receipts record startSeconds, width, height, frames, fps, contain fit and prepared-reference hash. The prepared source starts at timeline zero and already contains the selected source window: do not trim it again when replaying the portable graph.
7. Model-file integrity, runtime and output quality must be checked on the destination machine. Audio was removed from the conditioning preview; it was not promised in the output.

Media and workflow licenses remain those recorded by their owners in the manifest and pack. Open Genjutsu code is MIT.
